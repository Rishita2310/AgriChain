// Empty mod config
